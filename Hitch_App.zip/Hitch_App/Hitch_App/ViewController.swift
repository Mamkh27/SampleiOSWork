//
//  ViewController.swift
//  Hitch_App
//
//  Created by Manprit Heer on 5/12/21.
//

import UIKit
import ImagePicker
import CoreData
class ViewController: UIViewController, ImagePickerDelegate {
    
    @IBOutlet weak var userImage: UIImageView!
    var users: [Driver]?
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
 
    func fetchDriverInfo(){
        //fetch driver's information
        do {
            self.users = try context.fetch(Driver.fetchRequest())
        }catch{
        }
    }
    func wrapperDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
    }
    
    
    @IBOutlet var uploadButton: UIButton!
    
    @IBOutlet var imageView: UIImageView!
    func doneButtonDidPress(_ imagePicker: ImagePickerController, images: [UIImage]) {
        imagePicker.dismiss(animated: true, completion: nil)
        let newDriver = Driver(context: self.context)
        
                if let imageData = images[0].pngData() {
                    newDriver.img = imageData
                    newDriver.currentDriver = "1"
                    //save the data
                    do{
                    try self.context.save()
                    } catch{
                        print("There was an error in saving the image")
                    }
        }
    
        let nextViewController = self.storyboard?.instantiateViewController(withIdentifier: "BackgroundCheckVC") as! BackgroundCheckVC

        
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    
    
    func cancelButtonDidPress(_ imagePicker: ImagePickerController) {
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        uploadButton.layer.cornerRadius = 30
        // Do any additional setup after loading the view.
        
    }
    
    
    @IBAction func uploadButtonClicked(_ sender: Any) {
        
        let imagePickerController = ImagePickerController()
        
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
    }
}

