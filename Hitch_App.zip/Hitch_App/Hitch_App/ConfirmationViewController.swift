//
//  ConfirmationViewController.swift
//  Hitch_App
//
//  Created by Manprit Heer on 5/16/21.
//

import UIKit
import CoreData



class ConfirmationViewController: UIViewController {
    var users: [Driver]?
    @IBOutlet var userImage: UIImageView!
    @IBOutlet var ssnView: UIView!
    @IBOutlet var userSSN: UILabel!
    @IBOutlet var uploadButton: UIButton!
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func fetchDriverInfo(){
        
        let driver: Driver!
        let fetchUser: NSFetchRequest<Driver> = Driver.fetchRequest()
        fetchUser.predicate = NSPredicate(format: "currentDriver == 1")
        
        let results = try? context.fetch(fetchUser)
        
        if results?.count == 0 {
            
            // here you are inserting
            print("none exists)")
            driver = Driver(context: context)
        } else {
            // here you are updating
            print("updating driver")
            driver = results?.first
        }
        self.userImage.image = UIImage(data: (driver.img)!, scale: 1.0)
        self.userSSN.text = String(driver.ssn ?? "123-00-0000" )
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        ssnView.layer.cornerRadius = 10
        ssnView.layer.borderWidth = 1
        ssnView.layer.borderColor = CGColor(red: 196/255, green: 196/255, blue: 196/255, alpha: 1.0)
        uploadButton.layer.cornerRadius = 30
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchDriverInfo()
    }
    
}
