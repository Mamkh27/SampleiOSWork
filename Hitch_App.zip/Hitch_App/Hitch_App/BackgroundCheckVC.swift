//
//  BackgroundCheckVC.swift
//  Hitch_App
//
//  Created by Manprit Heer on 5/13/21.
//

import UIKit
import CoreData

class BackgroundCheckVC: UIViewController, UITextFieldDelegate {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet var textField1: UITextField!
    @IBOutlet var textField2: UITextField!
    @IBOutlet var textField3: UITextField!
    @IBOutlet var nextButton: UIButton!
    @IBOutlet var image: UIImage!
    @IBOutlet var SSNViewTopAnchor: NSLayoutConstraint!
    @IBOutlet var SSNView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textField1.delegate = self
        textField2.delegate = self
        textField3.delegate = self
        
        textField1.layer.cornerRadius = 10
        textField2.layer.cornerRadius = 10
        textField3.layer.cornerRadius = 10
        nextButton.layer.cornerRadius = 30
        // Do any additional setup after loading the view.
        
        //adding targets for each text field from OTP functionality
        textField1.addTarget(self, action: #selector(self.textDidChange(textfield:)), for: UIControl.Event.editingChanged)
        
        textField2.addTarget(self, action: #selector(self.textDidChange(textfield:)), for: UIControl.Event.editingChanged)
        
        textField3.addTarget(self, action: #selector(self.textDidChange(textfield:)), for: UIControl.Event.editingChanged)
        
    }
    
    @IBAction func nextButtonTapped(_ sender: Any) {
        let nextViewController = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmationViewController") as! ConfirmationViewController
        
        
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    var fields: [String?] = []
    var first_filled = false
    var second_filled = false
    @objc func textDidChange(textfield: UITextField){
        self.SSNView.frame.origin.y -= 350
        
        let text = textfield.text
        
        if(text?.utf16.count == 2){
            if textfield == textField2 && first_filled {
                fields.append(textField2.text)
                textField3.becomeFirstResponder()
                second_filled = true
                fields.append("-")
            }
        }
        if (text?.utf16.count == 3){
            if textfield == textField1{
                fields.append(textField1.text)
                textField2.becomeFirstResponder()
                first_filled = true
                fields.append("-")
            }
        }
        if( text?.utf16.count == 4){
            if(textfield == textField3 && second_filled){
                fields.append(textField3.text)
                print("the field is \(fields)")
                storeInformation()
                
            }
        }
    }
    
 
    func storeInformation(){
        // let newDriver = Driver(context: self.context)
        var word = String()
        for item in fields {
            word += item ?? ""
        }
        let driver: Driver!
        let fetchUser: NSFetchRequest<Driver> = Driver.fetchRequest()
        fetchUser.predicate = NSPredicate(format: "currentDriver == 1")
        
        let results = try? context.fetch(fetchUser)
        
        if results?.count == 0 {
            // here you are inserting
            print("none exists)")
            driver = Driver(context: context)
        } else {
            // here you are updating
            print("updating driver")
            driver = results?.first
        }
        driver.ssn = String(word)
    
        
        //save the data
        do{
            try self.context.save()
        } catch{
            print("There was an error in saving the image")
        }
        
    }
    @IBOutlet var backgroundCheckView: UIView!
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if(textField == textField1){
            textField1.becomeFirstResponder()
            backgroundCheckView.isHidden = true
            self.SSNView.frame.origin.y -= 350
            self.nextButton.frame.origin.y -= 350
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    func textFieldDidChangeSelection(_ textField: UITextField) {
        if (textField == textField1 || textField == textField2 || textField == textField3){
            self.SSNView.frame.origin.y -= 350
            self.nextButton.frame.origin.y -= 350
        }
    }
 }
